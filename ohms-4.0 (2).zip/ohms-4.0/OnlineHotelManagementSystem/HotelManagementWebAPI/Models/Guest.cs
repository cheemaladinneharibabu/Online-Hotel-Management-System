﻿using System;
using System.Collections.Generic;

namespace HotelManagementWebAPI.Models
{
    public partial class Guest
    {
        public Guest()
        {
            Invoice = new HashSet<Invoice>();
            MakeReservation = new HashSet<MakeReservation>();
            PaymentDetails = new HashSet<PaymentDetails>();
            ServicesBill = new HashSet<ServicesBill>();
        }

        public int MemberCode { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public string MobileNumber { get; set; }
        public string Gender { get; set; }
        public string City { get; set; }
        public string Pincode { get; set; }
        public string Citizenship { get; set; }
        public string Occupation { get; set; }
        public string DrivingLicence { get; set; }
        public string Email { get; set; }

        public virtual ICollection<Invoice> Invoice { get; set; }
        public virtual ICollection<MakeReservation> MakeReservation { get; set; }
        public virtual ICollection<PaymentDetails> PaymentDetails { get; set; }
        public virtual ICollection<ServicesBill> ServicesBill { get; set; }
    }
}
