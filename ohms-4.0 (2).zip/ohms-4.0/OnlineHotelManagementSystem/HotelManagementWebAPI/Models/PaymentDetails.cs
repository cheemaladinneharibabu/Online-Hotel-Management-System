﻿using System;
using System.Collections.Generic;

namespace HotelManagementWebAPI.Models
{
    public partial class PaymentDetails
    {
        public int PaymentId { get; set; }
        public DateTime PaymentTime { get; set; }
        public string PaymentMethod { get; set; }
        public int? MemberCode { get; set; }
        public int? InvoiceId { get; set; }
        public int Total { get; set; }

        public virtual Invoice Invoice { get; set; }
        public virtual Guest MemberCodeNavigation { get; set; }
    }
}
