﻿using System;
using System.Collections.Generic;

namespace HotelManagementWebAPI.Models
{
    public partial class Room
    {
        public Room()
        {
            MakeReservation = new HashSet<MakeReservation>();
        }

        public int RoomId { get; set; }
        public string RoomName { get; set; }
        public int BuildingNumber { get; set; }
        public int FloorNumber { get; set; }
        public string Status { get; set; }
        public string RoomType { get; set; }

        public virtual TypeOfRoom RoomTypeNavigation { get; set; }
        public virtual ICollection<MakeReservation> MakeReservation { get; set; }
    }
}
