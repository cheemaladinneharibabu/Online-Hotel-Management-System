﻿using System.Threading.Tasks;
using HotelManagementWebAPI.Data;
using HotelManagementWebAPI.Interface;
using HotelManagementWebAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HotelManagementWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReservationController : ControllerBase
    {
        private readonly IReservationData<MakeReservation> _reservationRepository;

        public ReservationController(IReservationData<MakeReservation> reservationRepository)
        {
            _reservationRepository = reservationRepository;
        }
        [HttpPost]
        public async Task<MakeReservation> PostReservation([FromBody] ReservationData reservationData)
        {
            var newreservation = await _reservationRepository.AddUser(reservationData);
            return newreservation;
        }
    }
}
