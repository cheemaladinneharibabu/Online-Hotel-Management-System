﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HotelManagementWebAPI.Data;
using HotelManagementWebAPI.Models;

namespace HotelManagementWebAPI.Interface
{
    public interface ITypeOfRoomData<T>
    {
        Task<TypeOfRoom> AddRoom(TypeOfRoomData roomData);
        Task<IEnumerable<TypeOfRoom>> Get();
    }
}
